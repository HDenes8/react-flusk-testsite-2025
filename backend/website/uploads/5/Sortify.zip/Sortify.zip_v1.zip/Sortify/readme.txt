Müködéshez szükséges:
Python: https://www.python.org/downloads/
Flask: 
               CMD -> pip install flask
                      pip install flask-login
                      pip install flask-sqlalchemy
Postgres for Flask -> pip install psycopg2-binary

Fájl letöltése után a main.py nevü fájlt kell elinditani az oldal elindulásához. Ezt több féle képpen is végbe mehet. 
Példa 1: Nyissuk meg VS-CODE fájl szerkesztőben majd navigáljunk a main.py fájlba majd job felül nyomjuk meg a start gombot. 
(Oldalra forditott háromszög) Ekkor meg fog jelenni egy kis szöveg amiben láthatjuk hogy elindult a program. 
Innen a *Running on http://........*-ra lesz szükség. CTRL nyomása közben rákattintva ki tudjuk jelölni. 
Majd ez bemásolva a keresőnkbe láthatjuk is az oldalt.


Példa 2: Ez elején különbözik csak. Amenniben nincs és nem is szeretnénk VS-CODE ot használni CMD-ből is elérhető. 
Navigáljunk a CMD-ben a megfelelő helyre ahol elérjük a Sortify névre hallgató programunkat, példa eset:
cd D:\repos\WorkStuff\Sortify

Majd a következő parancsal tudjuk futattni; python main.py
Ekkor meg fog jelenni egy kis szöveg amiben láthatjuk hogy elindult a program. Innen a *Running on http://........*-ra lesz szükség. 
CTRL nyomása közben rákattintva ki tudjuk jelölni. Majd ez bemásolva a keresőnmkbe láthatjuk is az oldalt.

Használat után ne flejtsük el leállitani. Visszatérünk oda ahol elinditottuk. 
VS-CODE terminal avagy CMD és a kiirt "CTRL + C" kombinációval le is tudjuk állitani.
