from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func

# User + Project => N-M Conn. 
class User_profile (db.Model, UserMixin):
    user_id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(255))
    nickname = db.Column(db.String(100))
    profile_pic = db.Column(db.String(255))
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))   
    mobile = db.Column(db.String(20))
    job = db.Column(db.String(100))
    created_date = db.Column(db.DateTime(timezone=True), default=func.now())
    user_activity_status = db.Column(db.Boolean, default=True)

    # Define the relationship to the Project model
    projects = db.relationship('Project', secondary='user_project', backref='users')

    def get_id(self):
        return str(self.user_id)
  
class Project(db.Model):
    project_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    created_date = db.Column(db.DateTime(timezone=True), default=func.now())
    project_activity_status = db.Column(db.Boolean, default=True)
    
    creator_id = db.Column(db.Integer, db.ForeignKey('user_profile.user_id'))

class User_Project(db.Model):
    __tablename__ = 'user_project'

    user_id = db.Column(db.Integer, db.ForeignKey('user_profile.user_id'), primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('project.project_id'), primary_key=True)
    role = db.Column(db.Enum('reader', 'editor', 'admin', 'owner', name='role_enum'), default='reader')
    connection_date = db.Column(db.DateTime(timezone=True), default=func.now())
    user_deleted_or_left_date = db.Column(db.DateTime(timezone=True), default=func.now()) # might need tweakige


class Invitation(db.Model):
    invitation_id = db.Column(db.Integer, primary_key=True)
    invited_email = db.Column(db.String(255))
    invite_date = db.Column(db.DateTime(timezone=True), default=func.now())

    referrer_id = db.Column(db.Integer, db.ForeignKey('user_profile.user_id'))
    project_id = db.Column(db.Integer, db.ForeignKey('project.project_id'))

class File_data(db.Model):
    file_data_id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.Text)
    short_comment = db.Column(db.String(20))

    project_id = db.Column(db.Integer, db.ForeignKey('project.project_id'))

class File_version(db.Model):
    version_id = db.Column(db.Integer, primary_key=True)
    version_number = db.Column(db.Integer)
    file_name = db.Column(db.String(255))
    file_type = db.Column(db.String(50))
    file_size = db.Column(db.Integer)
    description = db.Column(db.Text)
    last_version = db.Column(db.String(10))
    short_comment = db.Column(db.String(20))
    upload_date = db.Column(db.DateTime(timezone=True), default=func.now())

    file_id = db.Column(db.Integer, db.ForeignKey('file_data.file_data_id'))
    user_id = db.Column(db.Integer, db.ForeignKey('user_profile.user_id'))

