from flask import Blueprint, render_template, request, flash, url_for, redirect
from flask_login import login_required, current_user
from .models import User_profile, User_Project, Project
from . import db
from werkzeug.security import generate_password_hash, check_password_hash


views = Blueprint('views', __name__)

# @views.route('/create_project', methods=['GET', 'Post'])
# @login_required
# def create_project():
#     if request.method == 'POST':
#         project_name = request.form.get('projectName')
#         description = request.form.get('description')

#         if len(project_name) < 1:
#             flash('Project name is required!', category='error')
#         else:
#             new_project = Project(name=project_name, description=description, project_activity_status=True, creator_id=current_user.user_id)

#             db.session.add(new_project)
#             db.session.commit()

#             flash('Project created successfully!', category='success')
#             return redirect(url_for('views.home'))
    
#     return render_template("create_project.html", user=current_user)

@views.route('/settings', methods=['POST', 'GET'])
@login_required 
def settings():
    print(f"Request Method on Load: {request.method}")

    if request.method == 'POST':
        # Get form data
        email = request.form.get('email')
        full_name = request.form.get('fullName')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        # Optional fields
        nickname = request.form.get('nickname')
        mobile = request.form.get('mobile')
        job = request.form.get('job')

        print(f"Email: {email}, Full Name: {full_name}, Nickname: {nickname}, Mobile: {mobile}, Job: {job}")

        # Initialize error flag
        errors = False

        # Handle email change
        if email and email != current_user.email:
            if len(email) < 4:
                flash('Email must be greater than 3 characters.', category='error')
                errors = True
            elif User_profile.query.filter_by(email=email).first():
                flash('Email already exists.', category='error')
                errors = True

        # Handle full name change
        if full_name and full_name != current_user.full_name:
            if len(full_name) < 2:
                flash('Full name must be greater than 1 character.', category='error')
                errors = True

        # Handle password change
        if password1 or password2:
            if password1 != password2:
                flash('Passwords don\'t match.', category='error')
                errors = True
            elif len(password1) < 7:
                flash('Password must be at least 7 characters.', category='error')
                errors = True
            elif password1 and check_password_hash(current_user.password, password1):
                flash('Password can\'t be the old one.', category='error')
                errors = True

        # If there are errors, re-render the form with error messages
        if errors:
            return render_template("settings.html", user=current_user)

        # Update fields if no errors
        user = current_user

        # Only update the fields that are being changed
        if email and email != user.email:
            user.email = email
        if full_name and full_name != user.full_name:
            user.full_name = full_name
        if nickname and nickname != user.nickname:
            user.nickname = nickname
        if mobile and mobile != user.mobile:
            user.mobile = mobile
        if job and job != user.job:
            user.job = job

        # If a new password hash it
        if password1:
            user.password = generate_password_hash(password1, method='pbkdf2:sha256')

        # Commit changes to the database
        db.session.commit()
        flash('Your changes have been saved!', category='success')

        # Redirect to the settings page after update
        return redirect(url_for('views.settings')) 

    # Pre-fill the form with current user info when the page loads
    return render_template("settings.html", user=current_user)


@views.route('/create_project', methods=['GET', 'POST'])
@login_required
def create_project():
    if request.method == 'POST':
        project_name = request.form.get('projectName')
        description = request.form.get('description')

        if len(project_name) < 1:
            flash('Project name is required!', category='error')
        elif len(description) < 1:
            flash('Description is required!', category='error')
        else:
            new_project = Project(
                name=project_name, 
                description=description, 
                project_activity_status=True, 
                creator_id=current_user.user_id)

            db.session.add(new_project)
            db.session.commit()

            creator_relation = User_Project(
                user_id = current_user.user_id,
                project_id=new_project.project_id,
                role='owner'
            )

            db.session.add(creator_relation)
            db.session.commit()

            flash('Project created successfully!', category='success')
            return redirect(url_for('views.home'))
        
    return render_template("create_project.html", user=current_user)

@views.route('/')
@login_required
def home():
    user = User_profile.query.get(current_user.user_id)

    if not user:
        flash('USer not found.', category='error')
        return redirect(url_for('auth.login'))
    
    roles=[]
    user_project = User_Project.query.filter_by(user_id=user.user_id).all()

    for up in user_project:
        project = Project.query.get(up.project_id)
        roles.append({
            'project_name' : project.name,
            'role' : up.role
        })

    return render_template("home.html", user=user, roles=roles)


